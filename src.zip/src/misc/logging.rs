use eframe::egui;

#[derive(Default)]
pub struct MyApp {}

impl eframe::App for MyApp {
    fn ui(ctx: &egui::Context) {
        egui::Window::new("Log").show(ctx, |ui| {
            // draws the logger ui.
            egui_logger::logger_ui().show(ui);
        });
    }
}
