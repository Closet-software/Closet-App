mod app;
mod misc;
mod ui;

use app::MyApp;

pub const APP_NAME: &str = "Closet";

fn main() -> eframe::Result {
    let options = eframe::NativeOptions {
        centered: true,
        ..Default::default()
    };

    eframe::run_native(
        APP_NAME,
        options,
        Box::new(|cc| {
            egui_extras::install_image_loaders(&cc.egui_ctx);
            Ok(Box::new(MyApp::default()))
        }),
    )
}
