use eframe::egui;

#[derive(Default)]
pub struct MyApp {}

impl eframe::App for MyApp {
    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        egui::Window::new("Settings").show(ui.ctx(), |ui| {
            ui.label("Settings go here\n\n\n\n");
        });
    }
}
